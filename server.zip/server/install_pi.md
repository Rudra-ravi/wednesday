# Raspberry Pi Servo Control MCP Server Setup

This guide provides step-by-step instructions to set up and run the Python-based MCP servo control server on a Raspberry Pi 4 Model B.

## 1. Hardware Prerequisites

*   Raspberry Pi 4 Model B
*   MicroSD card (16GB or larger recommended) with Raspberry Pi OS (32-bit or 64-bit) flashed.
*   Reliable power supply for the Raspberry Pi (USB-C, 5V, 3A minimum).
*   Servos (as per your project needs).
*   Jumper wires for connecting servos to GPIO pins.
*   **Important:** GPIO pins used in `mcp_server.py` (default: 17, 27, 22, 23, 24, 25 in BCM numbering). Ensure your servos are wired correctly to these pins (Signal, Power, Ground).
*   **(Recommended)** A separate, adequate power supply for the servos, especially if using multiple or high-torque servos. Ensure the grounds (Raspberry Pi ground and servo power supply ground) are connected.

## 2. Software Prerequisites & Setup on Raspberry Pi

Connect to your Raspberry Pi (e.g., via SSH or with a monitor and keyboard). Open a terminal for the following commands.

### 2.1. Update Raspberry Pi OS

Keep your system up-to-date:
```bash
sudo apt update
sudo apt full-upgrade -y
```

### 2.2. Install Python and Essential Tools

Raspberry Pi OS usually comes with Python 3. Verify and install pip and venv if missing:
```bash
python3 --version
sudo apt install python3-pip python3-venv -y
```

### 2.3. Install RPi.GPIO Library

This library is needed for controlling the GPIO pins:
```bash
sudo apt install python3-rpi.gpio -y
```

### 2.4. Create Project Directory and Python Virtual Environment

It's best practice to use a virtual environment for Python projects.
```bash
mkdir ~/mcp_servo_project
cd ~/mcp_servo_project
python3 -m venv .venv
source .venv/bin/activate
```
*   You'll need to run `source .venv/bin/activate` every time you open a new terminal to work on this project.
*   To deactivate the virtual environment, simply type `deactivate`.

### 2.5. Install Required Python Packages

Inside your activated virtual environment (`(.venv) YourName@raspberrypi:~/mcp_servo_project $`), install the necessary Python libraries:
```bash
pip3 install uvicorn
```
For the `FastMCP` framework (`from mcp.server.fastmcp import FastMCP`):
*   **Option 1 (If `fastmcp` is a direct package):**
    ```bash
    pip3 install fastmcp
    ```
*   **Option 2 (If `mcp` is the package name):**
    ```bash
    pip3 install mcp
    ```
*   **Option 3 (If `FastMCP` is related to or uses FastAPI):** FastAPI is a common framework used with Uvicorn.
    ```bash
    pip3 install "fastapi[all]"
    ```
*If none of the above `fastmcp`/`mcp`/`fastapi` options work, you will need to identify the correct package name for the `mcp.server.fastmcp` module used in your `mcp_server.py` script and install it using `pip3 install <correct-package-name>`.*

## 3. Code Deployment

1.  Transfer your Python script files (`mcp_server.py` and `servo_handler.py`) to the `~/mcp_servo_project` directory on your Raspberry Pi. You can use `scp`, a USB drive, or clone a Git repository.
    *   Example using `scp` from your local machine (replace `your_local_path/` and `your_pi_ip`):
        ```bash
        scp your_local_path/mcp_server.py pi@your_pi_ip:~/mcp_servo_project/
        scp your_local_path/servo_handler.py pi@your_pi_ip:~/mcp_servo_project/
        ```
2.  Ensure both `mcp_server.py` and `servo_handler.py` are in the same directory (`~/mcp_servo_project`).

## 4. Running the Server

1.  Navigate to your project directory:
    ```bash
    cd ~/mcp_servo_project
    ```
2.  Activate the virtual environment (if not already active):
    ```bash
    source .venv/bin/activate
    ```
3.  Run the server script:
    ```bash
    python3 mcp_server.py
    ```
4.  You should see output indicating the server has started, similar to:
    ```
    Starting Raspberry Pi Servo Control MCP Server on 0.0.0.0:8011 using direct Uvicorn call...
    INFO:     Started server process [XXXXX]
    INFO:     Waiting for application startup.
    MCP Server Lifespan: Initializing Servo Controller...
    Initialized GPIO pin 17 for PWM.
    ... (similar messages for other configured pins) ...
    Servo controller initialized successfully.
    INFO:     Application startup complete.
    INFO:     Uvicorn running on http://0.0.0.0:8011 (Press CTRL+C to quit)
    ```

## 5. Testing the Server

1.  Find your Raspberry Pi's IP address. In the Raspberry Pi terminal, type:
    ```bash
    hostname -I
    ```
    This will usually show one or more IP addresses (e.g., `192.168.1.XX`).

2.  From another computer on the same network (or from the Pi itself using `localhost` or `127.0.0.1` instead of the IP), use a tool like `curl` or an API client (e.g., Postman) to send commands.

    **Example using `curl`:**
    Replace `RASPBERRY_PI_IP` with the actual IP address you found.
    ```bash
    curl -X POST http://RASPBERRY_PI_IP:8011/execute_servo_commands \
    -H "Content-Type: application/json" \
    -d '[
          {"pin": 17, "angle": 90, "duration_ms": 1000},
          {"pin": 27, "angle": 45}
        ]'
    ```
    This command attempts to:
    *   Move the servo on BCM pin 17 to 90 degrees over 1000 milliseconds.
    *   Move the servo on BCM pin 27 to 45 degrees using the default duration (500ms as per `servo_handler.py`).

3.  Check the terminal where `mcp_server.py` is running for log messages. Your servos should move if everything is correctly wired and configured. The `curl` command should receive a JSON string response indicating the status.

## 6. Troubleshooting Tips

*   **GPIO Permission Errors:**
    If you see errors like "No access to /dev/gpiomem", you might need to add your user to the `gpio` group:
    ```bash
    sudo adduser $(whoami) gpio
    ```
    Then, **reboot** your Raspberry Pi or log out and log back in for the group change to take effect. As a temporary test (not recommended for long-term), you can try running the server with `sudo`: `sudo python3 mcp_server.py`.
*   **Servo Jitter or No Movement:**
    *   **Power:** This is the most common issue. Ensure servos have adequate and stable power. The Raspberry Pi's 5V pins might not be sufficient for multiple or large servos. Use a separate power supply for the servos. **Remember to connect the ground of the servo power supply to a ground pin on the Raspberry Pi.**
    *   **Wiring:** Double-check signal, power, and ground connections for each servo.
    *   **Angle to Duty Cycle:** The `_angle_to_duty_cycle` method in `servo_handler.py` converts angles to PWM duty cycles. The default values (2% to 12% for 0-180 degrees) are common but might need adjustment for your specific servo models.
*   **Module Not Found Errors (e.g., `FastMCP`):**
    Ensure you are in the correct Python virtual environment (`source .venv/bin/activate`) and that you successfully installed the required package for `mcp.server.fastmcp` (see Step 2.5).
*   **Server Not Accessible Remotely:**
    *   Ensure your Raspberry Pi is connected to the network.
    *   Check that `0.0.0.0` is used as the host in `mcp_server.py` (which it is), allowing connections from any network interface.
    *   Check your Raspberry Pi's firewall settings (though `ufw` is often inactive by default on Raspberry Pi OS).

## 7. Running the Server on Boot (Optional)

For a more permanent setup, you might want the server to start automatically when the Raspberry Pi boots. `systemd` is a common way to achieve this.

1.  **Create a systemd service file:**
    ```bash
    sudo nano /etc/systemd/system/mcp_servo.service
    ```
2.  Paste the following content, adjusting paths if necessary (especially `User` and `ExecStart`):
    ```ini
    [Unit]
    Description=MCP Servo Control Server
    After=network.target

    [Service]
    User=pi # Or your username
    WorkingDirectory=/home/pi/mcp_servo_project # Adjust if your path is different
    ExecStart=/home/pi/mcp_servo_project/.venv/bin/python3 /home/pi/mcp_servo_project/mcp_server.py
    Restart=always
    StandardOutput=journal
    StandardError=journal

    [Install]
    WantedBy=multi-user.target
    ```
    *Save the file (Ctrl+X, then Y, then Enter in nano).*

3.  **Enable and start the service:**
    ```bash
    sudo systemctl daemon-reload
    sudo systemctl enable mcp_servo.service
    sudo systemctl start mcp_servo.service
    ```
4.  **Check status:**
    ```bash
    sudo systemctl status mcp_servo.service
    journalctl -u mcp_servo.service -f # To view logs
    ```
To stop the service: `sudo systemctl stop mcp_servo.service`
To disable autostart: `sudo systemctl disable mcp_servo.service` 